# Discountapp

npm install

gulp
