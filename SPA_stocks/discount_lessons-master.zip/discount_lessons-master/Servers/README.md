# Lesson 2 

- Simple usage of webapi

# Lesson 3

- Implementation of ORM (Entity Framework core) into the project

# Lesson 4

- Includes configurations JWT, ORM(EF core), WebAPi

# Lesson 4 (boilerplate) we could call the boilerplate for any projects that include the most used tech. stack such as JWT, ORM(EF core), WebAPi
