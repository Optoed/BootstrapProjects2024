# WebApiApplication
Пример RESTFull приложения на dotnet core для канала http://kursoft.ru

Открывать в Visual Studio 2017


В данном уроке мы реализуем базу на основе Entity Framework