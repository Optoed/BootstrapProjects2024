﻿using System.Collections.Generic;

namespace WebApiApplication
{
    public class Database : List<string>
    {
    }
}