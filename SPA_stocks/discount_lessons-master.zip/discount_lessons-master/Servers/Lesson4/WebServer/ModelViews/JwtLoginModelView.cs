﻿namespace WebServer.ModelViews
{
    public class JwtLoginModelView
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
