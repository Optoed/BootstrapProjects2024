import * as React from 'react';


export class HomeComponent extends React.Component {

    render()
    {
        return (
            <h3>
              <div>Lorem ipsum dolor sit amet.</div>
              <div>Eaque laborum vitae doloremque dolore!</div>
            </h3>
        );
    }
}
