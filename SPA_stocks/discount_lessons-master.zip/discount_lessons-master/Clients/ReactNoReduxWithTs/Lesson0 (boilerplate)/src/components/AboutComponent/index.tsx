import * as React from 'react';

export default class AboutComponent extends React.Component
{
    render()
    {
        return (
            <div>
                About
            </div>
        );
    }
}
