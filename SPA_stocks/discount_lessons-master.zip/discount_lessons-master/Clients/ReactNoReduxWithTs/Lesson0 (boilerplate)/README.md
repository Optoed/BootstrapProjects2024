# Frontend Boilerplate with React & TypeScript without Redux


## Setup

```
$ npm install
```

## Running

```
$ npm start
```

## Build

```
$ npm run build
```

# License

MIT
